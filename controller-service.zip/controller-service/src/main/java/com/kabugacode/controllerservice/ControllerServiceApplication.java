package com.kabugacode.controllerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllerServiceApplication.class, args);
	}

}
